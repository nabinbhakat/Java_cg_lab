package mypakage2;

import mypakage.*;

public class Child1 extends Parent {
    public void accessParentVariables() {
        System.out.println(publicVar); // Accessible (public)
        // System.out.println(privateVar); // Not accessible (private)
        System.out.println(protectedVar); // Accessible (protected)
        //System.out.println(packagePrivateVar); // Not accessible (package-private)
    }

    public void accessParentVariablesViaObject() {
        Parent parent = new Parent();
        System.out.println(parent.publicVar); // Accessible (public)
        // System.out.println(parent.privateVar); // Not accessible (private)
        // System.out.println(parent.protectedVar); // Not accessible (protected)
        // System.out.println(parent.packagePrivateVar); // Not accessible (package-private)
    }
}

