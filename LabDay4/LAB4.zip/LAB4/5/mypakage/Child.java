package mypakage;

public class Child extends Parent {
    public void accessParentVariables() {
        System.out.println(publicVar); // Accessible (public)
        // System.out.println(privateVar); // Not accessible (private)
        System.out.println(protectedVar); // Accessible (protected)
        System.out.println(packagePrivateVar); // Accessible (package-private)
    }
}