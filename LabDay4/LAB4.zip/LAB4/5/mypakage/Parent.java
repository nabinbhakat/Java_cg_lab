package mypakage;

public class Parent {
    public int publicVar = 1;
    private int privateVar = 2;
    protected int protectedVar = 3;
    int packagePrivateVar = 4;

    public Parent() {
        System.out.println("Parent's constructor");
    }
}
