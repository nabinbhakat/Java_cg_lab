package mypakage;

public class sub_class1 {
    public void accessParentVariables() {
        Parent parent = new Parent();
        System.out.println(parent.publicVar); // Accessible (public)
        // System.out.println(parent.privateVar); // Not accessible (private)
        System.out.println(parent.protectedVar); // Accessible (protected)
        System.out.println(parent.packagePrivateVar); // Accessible (package-private)
    }
}
