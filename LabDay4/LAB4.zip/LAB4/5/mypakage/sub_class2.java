package mypakage;

public class sub_class2 {
    public void accessParentVariables() {
        Parent parent = new Parent();
        System.out.println(parent.publicVar); // Accessible (public)
        // System.out.println(parent.privateVar); // Not accessible (private)
        // System.out.println(parent.protectedVar); // Not accessible (protected)
        // System.out.println(parent.packagePrivateVar); // Not accessible (package-private)
    }
}
