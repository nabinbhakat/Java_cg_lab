public class Parent {
    Parent(int age) {
        System.out.println("Under Constructor of Parent Class");
    }
    public void proc1() {
        System.out.println("Proc1 from Parent Called");
    }


    static {
        System.out.println("Static Initializer in Parent Class");
    }

    {
        System.out.println("Non-static Initializer in Parent Class");
    }
}
