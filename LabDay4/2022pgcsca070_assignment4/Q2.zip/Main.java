public class Main {
    public static void main(String[] args) {
        Parent p = new Child();
        p.proc1();
    }
}
