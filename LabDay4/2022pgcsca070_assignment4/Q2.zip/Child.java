public class Child extends Parent {

    Child() {
        super(19);
        System.out.println("Under non-static Constructor of Child Class");
    }
    public void proc1() {
        System.out.println("Proc1 from Child Called");
    }

    static {
        System.out.println("Static Initializer in Child Class");
    }

    {
        System.out.println("non-static Initializer in Child Class");
    }
}
