package pkg2;

public class NotChild1 {
    public void accessVariableFromSamePackage() {
        System.out.println(Parent.a + " " + Parent.b + " " + Parent.c + " " + Parent.d);
    }
}
