package pkg2;
import pkg.*;

public class Parent {
//   for Part (b)
    public int a;
    private int b;
    protected int c;
    int d;

//    for Parts (a), (c)
//    public static int a;
//    private static int b;
//    protected static int c;
//    static int d;
//     */

    public Parent() {
        System.out.println("Under Constructor of Parent Class");
    }

    {
        System.out.println("Under non-static Initializer of Parent Class");
    }

    static {
        System.out.println("Under Static Initializer of Parent Class");
    }
    static Parent getObject(String type) {
        switch (type) {
            case "Child" : return new Child();
            case "Child1" : return new Child1();
            default: return null;
        }
    }

}
