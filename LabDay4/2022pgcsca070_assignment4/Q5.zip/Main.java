import pkg.Child1;
public class Main {
    public static void main(String[] args) {

        Child1 c = new Child1();
        System.out.println("Accessing Directly.");
        c.accessDirectly();

        System.out.println();
        System.out.println("Acessing by Creating Object of Parent");
        c.accessViaParentObject();

    }
}
