package pkg;
import pkg2.Parent;

public class NotChild2 {
    public void accessVariableFromAnotherPackage() {
        System.out.println(Parent.a + " " + Parent.b + " " + Parent.c + " " + Parent.d);
    }
}
