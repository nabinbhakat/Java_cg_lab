package pkg;
import pkg2.Parent;
public class Child1 extends Parent {
    public Child1() {
        System.out.println("Under Constructor of Child1");
    }

    public void accessDirectly() {
        System.out.println(Parent.a + " " + Parent.b + " " + Parent.c + " " + Parent.d);
    }
    public void accessViaParentObject() {
        Parent p = new Child1();
        System.out.println(p.a + " " + p.b + " " + p.c + " " + p.d);
    }
}
