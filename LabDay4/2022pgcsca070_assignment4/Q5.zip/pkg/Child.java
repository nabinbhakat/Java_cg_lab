package pkg;
import pkg2.Parent;

public class Child extends Parent {

    public void accessVariable() {
        System.out.println(Parent.a + " " + Parent.b + " " + Parent.c + " " + Parent.d);
    }
    public Child() {
        System.out.println("Under Constructor of pkg.Child Class");
    }
    public void proc1() {
        System.out.println("Proc1 from pkg.Child Called");
    }

}
