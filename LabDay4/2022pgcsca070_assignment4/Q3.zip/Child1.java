public class Child1 extends Parent {
    Child1() {
        super(15);
        System.out.println("Under Constructor of Child1");
    }

    public void proc1(int size) {
        System.out.println("Under Proc1 of Child1 Class");
        System.out.println("Size = " + size);
    }
}
