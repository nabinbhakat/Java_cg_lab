public class Main {
    public static void main(String[] args) {
        Child1 p1 = (Child1) Parent.getObject("Child1");
        p1.proc1(17);
    }
}
