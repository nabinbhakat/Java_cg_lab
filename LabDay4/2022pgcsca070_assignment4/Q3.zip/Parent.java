public class Parent {
    Parent(int age) {
        System.out.println("Under Constructor of Parent Class");
    }
    public void proc1() {
        System.out.println("Proc1 from Parent Called");
    }

    static Parent getObject(String type) {
        switch (type) {
            case "Child" : return new Child();
            case "Child1" : return new Child1();
            default: return null;
        }
    }

}
