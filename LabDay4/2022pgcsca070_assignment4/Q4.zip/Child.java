public class Child extends Parent {

    Child() {
        System.out.println("Under Constructor of Child Class");
    }
    public void proc1() {
        System.out.println("Proc1 from Child Called");
    }

}
