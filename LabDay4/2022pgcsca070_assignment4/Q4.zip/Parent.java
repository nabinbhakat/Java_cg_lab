abstract class Parent {
    Parent() {
        System.out.println("Under Constructor of Parent Class");
    }
    abstract void proc1();

    {
        System.out.println("Under non-static Initializer of Parent Class");
    }

    static {
        System.out.println("Under Static Initializer of Parent Class");
    }
    static Parent getObject(String type) {
        switch (type) {
            case "Child" : return new Child();
            case "Child1" : return new Child1();
            default: return null;
        }
    }

}
