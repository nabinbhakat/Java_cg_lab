public class Main {
    public static void main(String[] args) {
        Child p = new Child();
        p.proc1();
        System.out.println();
        System.out.println();
        Child1 p1 = new Child1();
        p1.proc1();

    }
}
