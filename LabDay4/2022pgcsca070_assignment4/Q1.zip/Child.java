public class Child extends Parent {
    public void proc1() {
        System.out.println("Proc1 from Child Called");
    }
}
