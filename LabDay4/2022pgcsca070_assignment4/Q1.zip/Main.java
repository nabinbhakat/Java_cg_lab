public class Main {
    public static void main(String[] args) {
        Parent p = new Child();
        p.proc1();

        Child c = new Child();
        c.proc1();
    }
}
