public class Parent {
    Parent() {
        System.out.println("Constructor Called");
    }
    public void proc1() {
        System.out.println("Proc1 from Parent Called");
    }


}
